package be.pizza.core;
public interface PizzaBeleg extends Pizza{
    public String getBeschrijving();
    public double getPrijs();
    public Grootte getGrootte();
}