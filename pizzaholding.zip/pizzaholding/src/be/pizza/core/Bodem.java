package be.pizza.core;
public interface Bodem{
}
