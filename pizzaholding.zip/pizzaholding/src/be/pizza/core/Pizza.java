package be.pizza.core;
public interface Pizza{
    public String getBeschrijving();
    public double getPrijs();
    public Grootte getGrootte();
}