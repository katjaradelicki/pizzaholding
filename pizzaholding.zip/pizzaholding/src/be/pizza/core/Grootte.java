package be.pizza.core;
public interface Grootte{
    public double getVerhouding();
}
