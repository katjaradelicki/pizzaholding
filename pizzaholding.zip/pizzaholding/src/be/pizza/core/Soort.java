package be.pizza.core;
public interface Soort{
}
