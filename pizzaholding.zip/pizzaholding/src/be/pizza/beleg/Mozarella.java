package be.pizza.beleg;
import be.pizza.core.Pizza;
import be.pizza.core.Grootte;
import be.pizza.core.PizzaBeleg;
public class Mozarella implements PizzaBeleg{
    private Pizza pizza;
    public Mozarella(Pizza pizza){
        this.pizza=pizza;
    }
    public String getBeschrijving(){
        return pizza.getBeschrijving()+", mozarella";
    }
    public double getPrijs(){
        return pizza.getPrijs()+1.3*pizza.getGrootte().getVerhouding();
    }
    public Grootte getGrootte(){
        return pizza.getGrootte();
    }
}