package be.pizza.beleg;
import be.pizza.core.Pizza;
import be.pizza.core.Grootte;
import be.pizza.core.PizzaBeleg;
public class ZwarteOlijven implements PizzaBeleg{
    private Pizza pizza;
    public ZwarteOlijven(Pizza pizza){
        this.pizza=pizza;
    }
    public String getBeschrijving(){
        return pizza.getBeschrijving()+", zwarte olijven";
    }
    public double getPrijs(){
        return pizza.getPrijs()+1.1*pizza.getGrootte().getVerhouding();
    }
    public Grootte getGrootte(){
        return pizza.getGrootte();
    }
}