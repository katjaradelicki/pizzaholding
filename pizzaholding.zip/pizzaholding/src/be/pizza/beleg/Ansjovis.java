package be.pizza.beleg;
import be.pizza.core.Pizza;
import be.pizza.core.Grootte;
import be.pizza.core.PizzaBeleg;
public class Ansjovis implements PizzaBeleg{
    private Pizza pizza;
    public Ansjovis(Pizza pizza){
        this.pizza=pizza;
    }
    public String getBeschrijving(){
        return pizza.getBeschrijving()+", zuiderse ansjovis";
    }
    public double getPrijs(){
        return pizza.getPrijs()+1.0*pizza.getGrootte().getVerhouding();
    }
    public Grootte getGrootte(){
        return pizza.getGrootte();
    }
}