package be.pizza.beleg;
import be.pizza.core.Pizza;
import be.pizza.core.Grootte;
import be.pizza.core.PizzaBeleg;
public class Kappers implements PizzaBeleg{
    private Pizza pizza;
    public Kappers(Pizza pizza){
        this.pizza=pizza;
    }
    public String getBeschrijving(){
        return pizza.getBeschrijving()+", kappers";
    }
    public double getPrijs(){
        return pizza.getPrijs()+0.4*pizza.getGrootte().getVerhouding();
    }
    public Grootte getGrootte(){
        return pizza.getGrootte();
    }
}