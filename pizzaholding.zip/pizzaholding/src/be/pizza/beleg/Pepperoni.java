package be.pizza.beleg;
import be.pizza.core.Pizza;
import be.pizza.core.Grootte;
import be.pizza.core.PizzaBeleg;
public class Pepperoni implements PizzaBeleg{
    private Pizza pizza;
    public Pepperoni(Pizza pizza){
        this.pizza=pizza;
    }
    public String getBeschrijving(){
        return pizza.getBeschrijving()+", pepperoniworst";
    }
    public double getPrijs(){
        return pizza.getPrijs()+1.2*pizza.getGrootte().getVerhouding();
    }
    public Grootte getGrootte(){
        return pizza.getGrootte();
    }
}