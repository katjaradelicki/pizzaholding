package be.pizzaitalia.specials;
import be.pizza.core.Bodem;
public enum PizzaBodem implements Bodem{
    ORIGINALE;
}
